python3 kn.py $1/twitter_rv.net-seed  300 tigergraph 1 notes latency; 
python3 kn.py $1/twitter_rv.net-seed  300 tigergraph 2 notes latency; 
python3 kn.py $1/twitter_rv.net-seed  10 tigergraph 3 notes latency; 
python3 kn.py $1/twitter_rv.net-seed  10 tigergraph 6 notes latency; 
python3 wcc.py twitter-rv tigergraph 3;
python3 pg.py twitter-rv tigergraph 10 3
